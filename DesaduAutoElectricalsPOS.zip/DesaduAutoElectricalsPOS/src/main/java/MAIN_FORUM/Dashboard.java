/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MAIN_FORUM;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class Dashboard extends javax.swing.JFrame {
 
     private Connection conn;
    public Dashboard() {
        initComponents();
        dbconnect();
        updateLabels();
        setLocationRelativeTo(null);
    }
    
  private void updateLabels() {
        totalitems.setText("<html><div style='text-align:center'>Total Items:<br>" + getTotalItems() + "</div></html>");
        totalitems1.setText("<html><div style='text-align:center'>Total Customers:<br>" + getTotalCustomers() + "</div></html>");
        totalitems2.setText("<html><div style='text-align:center'>Total Vehicles:<br>" + getTotalVehicles() + "</div></html>");
        totalitems4.setText("<html><div style='text-align:center'>Total Employees:<br>" + getTotalEmployees() + "</div></html>");
        totalitems5.setText("<html><div style='text-align:center'>Daily Sales ($):<br>" + String.format("%.2f", getTotalDailySales()) + "</div></html>");
        totalitems3.setText("<html><div style='text-align:center'>Monthly Sales ($):<br>" + String.format("%.2f", getTotalMonthlySales()) + "</div></html>");
     
    }
       private void dbconnect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EAD1?useSSL=false","root","");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Database connection error: " + e.getMessage());
        }
    }
    private int getTotalItems() {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM Itemstock")) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching total items: " + e.getMessage());
        }
        return 0;
    }

    private int getTotalEmployees() {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM EmployeeDetails")) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching total employees: " + e.getMessage());
        }
        return 0;
    }

    private int getTotalCustomers() {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM CustomerDetails")) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching total customers: " + e.getMessage());
        }
        return 0;
    }

    private int getTotalVehicles() {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM Vehicle")) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching total vehicles: " + e.getMessage());
        }
        return 0;
    }

    private double getTotalDailySales() {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COALESCE(SUM(total_price), 0) AS total FROM CashierDetails WHERE DATE(date) = CURDATE()")) {
            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching daily sales: " + e.getMessage());
        }
        return 0.0;
    }

    private double getTotalMonthlySales() {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT COALESCE(SUM(total_price), 0) AS total FROM CashierDetails " +
                             "WHERE YEAR(date) = YEAR(CURDATE()) AND MONTH(date) = MONTH(CURDATE())")) {
            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching monthly sales: " + e.getMessage());
        }
        return 0.0;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jemployeetotal = new javax.swing.JPanel();
        totalitems4 = new javax.swing.JLabel();
        jcustomertotal = new javax.swing.JPanel();
        totalitems1 = new javax.swing.JLabel();
        jitemtotal = new javax.swing.JPanel();
        totalitems = new javax.swing.JLabel();
        jvehicletotal = new javax.swing.JPanel();
        totalitems2 = new javax.swing.JLabel();
        jdailysales = new javax.swing.JPanel();
        totalitems5 = new javax.swing.JLabel();
        jmonthlysales = new javax.swing.JPanel();
        totalitems3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setResizable(false);

        jemployeetotal.setBackground(new java.awt.Color(102, 102, 255));

        totalitems4.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        totalitems4.setForeground(new java.awt.Color(0, 0, 0));
        totalitems4.setText("Total Employees:");

        javax.swing.GroupLayout jemployeetotalLayout = new javax.swing.GroupLayout(jemployeetotal);
        jemployeetotal.setLayout(jemployeetotalLayout);
        jemployeetotalLayout.setHorizontalGroup(
            jemployeetotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jemployeetotalLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(totalitems4)
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jemployeetotalLayout.setVerticalGroup(
            jemployeetotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jemployeetotalLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(totalitems4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jcustomertotal.setBackground(new java.awt.Color(255, 102, 153));

        totalitems1.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        totalitems1.setForeground(new java.awt.Color(0, 0, 0));
        totalitems1.setText("Total Customers:");

        javax.swing.GroupLayout jcustomertotalLayout = new javax.swing.GroupLayout(jcustomertotal);
        jcustomertotal.setLayout(jcustomertotalLayout);
        jcustomertotalLayout.setHorizontalGroup(
            jcustomertotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jcustomertotalLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(totalitems1)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jcustomertotalLayout.setVerticalGroup(
            jcustomertotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jcustomertotalLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(totalitems1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jitemtotal.setBackground(new java.awt.Color(255, 255, 0));

        totalitems.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        totalitems.setForeground(new java.awt.Color(0, 0, 0));
        totalitems.setText("Total Items:");

        javax.swing.GroupLayout jitemtotalLayout = new javax.swing.GroupLayout(jitemtotal);
        jitemtotal.setLayout(jitemtotalLayout);
        jitemtotalLayout.setHorizontalGroup(
            jitemtotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jitemtotalLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(totalitems)
                .addContainerGap(53, Short.MAX_VALUE))
        );
        jitemtotalLayout.setVerticalGroup(
            jitemtotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jitemtotalLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(totalitems)
                .addContainerGap(100, Short.MAX_VALUE))
        );

        jvehicletotal.setBackground(new java.awt.Color(255, 0, 0));

        totalitems2.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        totalitems2.setForeground(new java.awt.Color(0, 0, 0));
        totalitems2.setText("Total Vehicles:");

        javax.swing.GroupLayout jvehicletotalLayout = new javax.swing.GroupLayout(jvehicletotal);
        jvehicletotal.setLayout(jvehicletotalLayout);
        jvehicletotalLayout.setHorizontalGroup(
            jvehicletotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jvehicletotalLayout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addComponent(totalitems2)
                .addGap(56, 56, 56))
        );
        jvehicletotalLayout.setVerticalGroup(
            jvehicletotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jvehicletotalLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(totalitems2)
                .addContainerGap(98, Short.MAX_VALUE))
        );

        jdailysales.setBackground(new java.awt.Color(0, 255, 102));

        totalitems5.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        totalitems5.setForeground(new java.awt.Color(0, 0, 0));
        totalitems5.setText("Daily Sales:");

        javax.swing.GroupLayout jdailysalesLayout = new javax.swing.GroupLayout(jdailysales);
        jdailysales.setLayout(jdailysalesLayout);
        jdailysalesLayout.setHorizontalGroup(
            jdailysalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdailysalesLayout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(totalitems5)
                .addGap(60, 60, 60))
        );
        jdailysalesLayout.setVerticalGroup(
            jdailysalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jdailysalesLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(totalitems5)
                .addContainerGap(91, Short.MAX_VALUE))
        );

        jmonthlysales.setBackground(new java.awt.Color(0, 204, 204));

        totalitems3.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        totalitems3.setForeground(new java.awt.Color(0, 0, 0));
        totalitems3.setText("Monthly Sales:");

        javax.swing.GroupLayout jmonthlysalesLayout = new javax.swing.GroupLayout(jmonthlysales);
        jmonthlysales.setLayout(jmonthlysalesLayout);
        jmonthlysalesLayout.setHorizontalGroup(
            jmonthlysalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jmonthlysalesLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(totalitems3)
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jmonthlysalesLayout.setVerticalGroup(
            jmonthlysalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jmonthlysalesLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(totalitems3)
                .addContainerGap(99, Short.MAX_VALUE))
        );

        jButton1.setText("Close");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setForeground(new java.awt.Color(153, 255, 255));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Report Overview");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(412, 412, 412)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jvehicletotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jmonthlysales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jemployeetotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(114, 114, 114)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jdailysales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(202, 202, 202))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jcustomertotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jitemtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(106, 106, 106)))))
                        .addGap(0, 203, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(483, 483, 483))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jdailysales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jcustomertotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jitemtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jmonthlysales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jemployeetotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jvehicletotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(64, 64, 64))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jcustomertotal;
    private javax.swing.JPanel jdailysales;
    private javax.swing.JPanel jemployeetotal;
    private javax.swing.JPanel jitemtotal;
    private javax.swing.JPanel jmonthlysales;
    private javax.swing.JPanel jvehicletotal;
    private javax.swing.JLabel totalitems;
    private javax.swing.JLabel totalitems1;
    private javax.swing.JLabel totalitems2;
    private javax.swing.JLabel totalitems3;
    private javax.swing.JLabel totalitems4;
    private javax.swing.JLabel totalitems5;
    // End of variables declaration//GEN-END:variables
}
