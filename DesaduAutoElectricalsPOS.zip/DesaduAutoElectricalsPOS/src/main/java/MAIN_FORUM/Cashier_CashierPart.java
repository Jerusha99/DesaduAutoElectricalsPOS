/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MAIN_FORUM;

import Admin_Login_Form.Admin_Or_CashierLogin;
import MAIN_FORUM.*;
import java.sql.ResultSet;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.print.PrintService;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Acer
 */
public class Cashier_CashierPart extends javax.swing.JFrame {
private static int billCounter = 1000;
 private Connection conn = null;  
     PreparedStatement pstmt = null;
    /**
     * Creates new form Cashier_Main_Form
     */
    public Cashier_CashierPart() {
        initComponents();
        generateBillAndItemIds();
        dbconnect();
        
        itemComboBoxActionPerformed();
        numberComboBoxActionPerformed();
    populateVehicleComboBox(); // Add this
    populateItemComboBox();
    retrieveAndGenerateBillId();
         jTextArea1.setEditable(false);
         txtbillId.setEditable(false);
         txtitemname.setEditable(false);
         txtpriceperitem.setEditable(false);
         txttelephone.setEditable(false);
         txttotal.setEditable(false);
         
          itemcombobox.addActionListener((ActionEvent evt) -> {
              updatePricePerItem();
           
              updateItemName();
              
        });
                   VehicleComboBox.addActionListener((ActionEvent evt) -> {
      updatenumberItem();
              
        });

}
    private void numberComboBoxActionPerformed() {
    String selectedItemId = (String) VehicleComboBox.getSelectedItem();
    if (selectedItemId != null) {
        updatenumberItem();
    }
}
    private void updatenumberItem() {
    String selectedItem = VehicleComboBox.getSelectedItem().toString();
    System.out.println("Selected item: " + selectedItem); // Debug line
    
    getCustomerDetails(selectedItem);
    
    // We assume the fields txtcusname and txttelenumber are updated by getCustomerDetails()
}
    private void getCustomerDetails(String itemId) {
    try {
        // SQL query to get customer name and mobile number
        String query = "SELECT  cmobilenumber FROM CustomerDetails WHERE cVehicleNumber = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        
        // Extract vehicle number from itemId
        String vehicleNumber = itemId.split(" - ")[0]; // Adjust this line if itemId format is different
        System.out.println("Extracted vehicle number: " + vehicleNumber); // Debugging line
        pstmt.setString(1, vehicleNumber);
        
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
         
            String telephoneNumber = rs.getString("cmobilenumber");
            
            // Assuming you have text fields for customer name and telephone number
           
            txttelephone.setText(telephoneNumber);
            
           
            System.out.println("Retrieved telephone number: " + telephoneNumber); // Debug line
        } else {
            // Handle case where no data is returned
            JOptionPane.showMessageDialog(this, "No customer found with vehicle number: " + vehicleNumber, "No Data", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Vehicle_Details.class.getName()).log(Level.SEVERE, "SQL Error: ", ex);
        JOptionPane.showMessageDialog(this, "Failed to retrieve customer details.", "Database Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        Logger.getLogger(Vehicle_Details.class.getName()).log(Level.SEVERE, "General Error: ", e);
        JOptionPane.showMessageDialog(this, "An unexpected error occurred.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void itemComboBoxActionPerformed() {                                             
    String selectedItemId = (String) itemcombobox.getSelectedItem();
    
    // Debugging information
    System.out.println("Selected item ID: " + selectedItemId);
    
    if (selectedItemId != null) {
        // Retrieve item price
          String itemName = getItemName(selectedItemId);
        double itemPrice = getItemPrice(selectedItemId);
       
   
        // Retrieve item name
      
        
        // Debugging information
        System.out.println("Retrieved price: " + itemPrice);
        System.out.println("Retrieved item name: " + itemName);
        
        // Set price and item name to the respective text fields
        txtpriceperitem.setText(String.format("%.2f", itemPrice));
        txtitemname.setText(itemName);
        System.out.println("Item name set in textbox: " + txtitemname.getText()); // Debug line
    }
}
 private void updatePricePerItem() {
    String selectedItem = itemcombobox.getSelectedItem().toString();
    System.out.println("Selected item: " + selectedItem); // Debug line
    
    double price = getItemPrice(selectedItem);
    System.out.println("Price to set: " + price); // Debug line
    
    // Check if price is correctly retrieved and then set it to the textbox
    if (price > 0) {
        txtpriceperitem.setText(String.format("%.2f", price));
        System.out.println("Price set in textbox: " + txtpriceperitem.getText()); // Debug line
    } else {
        System.out.println("Price not set, check the retrieved value."); // Debug line
    }
}
private void updateItemName() {
    String selectedItem = itemcombobox.getSelectedItem().toString();
    System.out.println("Selected item: " + selectedItem); // Debug line
    
    String itemname = getItemName(selectedItem);
    System.out.println("Item name to set: " + itemname); // Debug line
    
    // Check if item name is correctly retrieved and then set it to the textbox
    if (itemname != null) {
        txtitemname.setText(itemname);
        System.out.println("Item name set in textbox: " + txtitemname.getText()); // Debug line
    } else {
        System.out.println("Item name not set, check the retrieved value."); // Debug line
    }
}

private double getItemPrice(String itemId) {
    double price = 0.0;
    try {
        String query = "SELECT Iprice FROM Itemstock WHERE Iid = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, itemId);
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            price = rs.getDouble("Iprice");
        }
    } catch (SQLException ex) {
        Logger.getLogger(Cashier_CashierPart.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(this, "Failed to retrieve item price.", "Database Error", JOptionPane.ERROR_MESSAGE);
    }
    return price;
}
private String getItemName(String itemId) {
    String itemName = null;
    try {
        String query = "SELECT Iname FROM Itemstock WHERE Iid = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, itemId);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            itemName = rs.getString("Iname");
            System.out.println("Retrieved item name: " + itemName); // Debug line
        } else {
            System.out.println("No item found for ID: " + itemId); // Debug line
        }
    } catch (SQLException ex) {
        Logger.getLogger(Cashier_CashierPart.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(this, "Failed to retrieve item name.", "Database Error", JOptionPane.ERROR_MESSAGE);
    }
    return itemName;
}

     public void dbconnect(){                    //   ------------------------USEFULL--------------
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
             conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/EAD1?useSSL=false","root","");

        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,e.toString());
        }
    }
private void retrieveAndGenerateBillId() {
    String query = "SELECT bill_id FROM CashierDetails ORDER BY bill_id DESC LIMIT 1";
    String lastBillId = "";
    int newBillId = 1; // Default to 1 if no bills exist

    try (
         Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query)) {

        // Check if there are results
        if (rs.next()) {
            lastBillId = rs.getString("bill_id");
            newBillId = Integer.parseInt(lastBillId) + 1; // Increment the last bill ID
        }

        // Format the new bill ID
        String formattedBillId = String.format("%04d", newBillId);

        // Set the new bill ID to the text field
        txtbillId.setText(formattedBillId);

    } catch (SQLException e) {
    }
}


private void generateBillAndItemIds() {
        // Generate Bill ID
        billCounter++;
        String billId = String.format("BILL%04d", billCounter); // e.g., BILL1001, BILL1002, ...

        // Set IDs to text fields
        txtbillId.setText(billId);
      
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtquantity = new javax.swing.JTextField();
        txtbillId = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtpriceperitem = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtservicecharge = new javax.swing.JTextField();
        txttelephone = new javax.swing.JTextField();
        txttotal = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        VehicleComboBox = new javax.swing.JComboBox<>();
        itemcombobox = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtitemname = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        addtableitem = new javax.swing.JTable();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel1.setText("Bill ID");

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(153, 255, 255));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Billing Page");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(412, 412, 412)
                .addComponent(jLabel2)
                .addContainerGap(454, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel2)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel3.setText("Item ID");

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel4.setText("Quantity");

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel6.setText("Price per Item");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setText("Bill Printing");

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel8.setText("Date");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel9.setText("Telephone Number");

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel10.setText("Vehicle Number");

        jLabel11.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel11.setText("Total Price");

        txttotal.setEditable(false);

        jLabel12.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel12.setText("Service Charge");

        jButton1.setText("Calculate");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Print");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("LogOut");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(jTextArea1);

        VehicleComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VehicleComboBoxActionPerformed(evt);
            }
        });

        itemcombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemcomboboxActionPerformed(evt);
            }
        });

        jButton5.setText("Reload");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel5.setText("Item Name");

        jButton6.setText("ADD ITEM");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        addtableitem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item ID", "Item Name", "Quantity", "Price"
            }
        ));
        addtableitem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addtableitemMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(addtableitem);

        jButton7.setText("REMOVE ITEM");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(141, 141, 141)
                            .addComponent(jLabel7))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(32, 32, 32)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(87, 87, 87)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtitemname)
                                .addComponent(txtbillId, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                                .addComponent(itemcombobox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGap(32, 32, 32)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtquantity, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                                .addComponent(txtpriceperitem)
                                .addComponent(jDateChooser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtservicecharge, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txttotal)
                                .addComponent(txttelephone, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(VehicleComboBox, 0, 217, Short.MAX_VALUE)
                                .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(txtbillId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(itemcombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtitemname, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtquantity, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtpriceperitem, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(jButton6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton7)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(VehicleComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txttelephone, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(5, 5, 5)
                                .addComponent(txtservicecharge, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txttotal, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(60, 60, 60)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton3)
                            .addComponent(jButton4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5)
                        .addGap(82, 82, 82))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        txtbillId.setText("");
        txtitemname.setText("");
        txtquantity.setText("");
        jDateChooser.setDate(null);
        txttelephone.setText("");
        txtpriceperitem.setText("");
        txtitemname.setText("");
        txtservicecharge.setText("");
        txttotal.setText("");
        jTextArea1.setText("");
   retrieveAndGenerateBillId();
    DefaultTableModel model = (DefaultTableModel) addtableitem.getModel();
    model.setRowCount(0);  // This will clear all the rows in the table
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    // Check if any fields are empty
    if (txtbillId.getText().isEmpty() ||
        txtquantity.getText().isEmpty() ||
        jDateChooser.getDate() == null ||  // Check if jDateChooser is empty
        txtpriceperitem.getText().isEmpty() ||
        txtservicecharge.getText().isEmpty() ||
        txttelephone.getText().isEmpty()) {

        JOptionPane.showMessageDialog(null, "Fields are empty!");
        return; // Exit the method if fields are empty
    }

    try {
        // Get the table model and row count
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) addtableitem.getModel();
        int rowCount = model.getRowCount();

        double totalPrice = 0.0;

        // Iterate through each row to accumulate the total price
        for (int i = 0; i < rowCount; i++) {
            int quantity = Integer.parseInt(model.getValueAt(i, 2).toString());
            double pricePerItem = Double.parseDouble(model.getValueAt(i, 3).toString());

            // Calculate total price for the current item and accumulate
            totalPrice += (quantity * pricePerItem);

            // Get the item ID from the table
            String itemID = model.getValueAt(i, 0).toString();

            // Check the current stock for the selected item
            String selectQuery = "SELECT Iqty FROM Itemstock WHERE Iid = ?";
            PreparedStatement pstmt = conn.prepareStatement(selectQuery);
            pstmt.setString(1, itemID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int currentQuantity = rs.getInt("Iqty");

                if (currentQuantity < quantity) {
                    // If current stock is less than the required quantity, show out-of-stock message and return
                    JOptionPane.showMessageDialog(this, "Out of Stock for item ID: " + itemID);
                    return; // Exit the method to prevent further execution
                }

                // Reduce the quantity in the Itemstock table
                int newQuantity = currentQuantity - quantity;
                String updateQuery = "UPDATE Itemstock SET Iqty = ? WHERE Iid = ?";
                pstmt = conn.prepareStatement(updateQuery);
                pstmt.setInt(1, newQuantity);
                pstmt.setString(2, itemID);
                pstmt.executeUpdate();
            } else {
                JOptionPane.showMessageDialog(this, "Item ID not found: " + itemID);
                return; // Exit the method if item ID is not found
            }
        }

        // Get the service charge and add it to the total price
        double serviceCharge = Double.parseDouble(txtservicecharge.getText());
        totalPrice += serviceCharge;

        // Display the total price
        txttotal.setText(String.format("%.2f", totalPrice));

        // Prepare SQL insert statement for CashierDetails
        String billId = txtbillId.getText();
        String selectedVehicle = (String) VehicleComboBox.getSelectedItem();

        // Prepare the statement for batch insert
        PreparedStatement pstmt = conn.prepareStatement(
            "INSERT INTO CashierDetails (bill_id, item_id, quantity, price_per_item, date, telephone_number, vehicle_number, service_charge, total_price, item_name) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        for (int i = 0; i < rowCount; i++) {
            String itemID = model.getValueAt(i, 0).toString();
            int quantity = Integer.parseInt(model.getValueAt(i, 2).toString());
            double pricePerItem = Double.parseDouble(model.getValueAt(i, 3).toString());
            String itemName = model.getValueAt(i, 1).toString(); // Retrieve item name from the table

            // Set the values in the prepared statement
            pstmt.setString(1, billId);
            pstmt.setString(2, itemID);
            pstmt.setInt(3, quantity);
            pstmt.setDouble(4, pricePerItem);
            pstmt.setDate(5, new java.sql.Date(jDateChooser.getDate().getTime())); // Correctly convert date
            pstmt.setString(6, txttelephone.getText());
            pstmt.setString(7, selectedVehicle);
            pstmt.setDouble(8, 0); // Service charge is included in the total price, so set to 0 here
            pstmt.setDouble(9, totalPrice); // Use the total price with service charge
            pstmt.setString(10, itemName);

            // Execute the insert into CashierDetails
            pstmt.addBatch(); // Add to batch instead of executing immediately
        }

        // Execute all inserts in batch
        pstmt.executeBatch();

        JOptionPane.showMessageDialog(this, "Cashier details saved successfully.");

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        Logger.getLogger(Cashier_CashierPart.class.getName()).log(Level.SEVERE, null, ex);
    } catch (HeadlessException e) {
        JOptionPane.showMessageDialog(null, "Something went wrong: " + e.getMessage());
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
      
        new Admin_Or_CashierLogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        PrinterJob job = PrinterJob.getPrinterJob();
PrintService[] printers = PrinterJob.lookupPrintServices();

if (printers.length == 0) {
    System.out.println("No printers found!");
} else {
    for (PrintService printer : printers) {
        System.out.println("Available printer: " + printer.getName());
    }
}

      if (txtbillId.getText().isEmpty() ||
        txtquantity.getText().isEmpty() ||
        jDateChooser.getDate() == null ||  // Check if jDateChooser is empty
        txtpriceperitem.getText().isEmpty() ||
        txtservicecharge.getText().isEmpty() ||
        txttelephone.getText().isEmpty()) {

        JOptionPane.showMessageDialog(null, "Fields are empty!");
        jTextArea1.setText("");
    } else {
        Date obj = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Format for date
        String dateString = sdf.format(obj);

        // Clear the text area
        jTextArea1.setText("");

  // Add header
jTextArea1.append(String.format("%-40s\n", "                                          Desandu Auto Electricals"));
jTextArea1.append(String.format("%-40s\n", "                                                    Invoice"));
jTextArea1.append(String.format("%-40s\n", "------------------------------------------------------------------------------------------------"));
jTextArea1.append(String.format("Date: %-25s\n", dateString));
jTextArea1.append(String.format("%-40s\n", "------------------------------------------------------------------------------------------------"));
jTextArea1.append(String.format("Bill Id: %-25s\n", txtbillId.getText()));

        // Get the table model and row count
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) addtableitem.getModel();
        int rowCount = model.getRowCount();
jTextArea1.append(String.format("%-10s %-20s %-8s %-12s\n", "Item No", "      Item Name", "         Quantity", "         Price Per Item"));
jTextArea1.append(String.format("%-40s\n", "------------------------------------------------------------------------------------------------"));

        double totalPrice = 0.0;
        for (int i = 0; i < rowCount; i++) {
            String itemID = model.getValueAt(i, 0).toString();
            String itemName = model.getValueAt(i, 1).toString();
            int quantity = Integer.parseInt(model.getValueAt(i, 2).toString());
            double pricePerItem = Double.parseDouble(model.getValueAt(i, 3).toString());
            double itemTotal = quantity * pricePerItem;
            totalPrice += itemTotal;
// Append item details to the text area// Append item details to the text area
jTextArea1.append(String.format("%-10s              %-20s\n", itemID, itemName));
jTextArea1.append(String.format("                                                               %-8d                   %-12.2f\n",  quantity, pricePerItem));
        }

        // Add the remaining invoice details
        double serviceCharge = Double.parseDouble(txtservicecharge.getText());
        totalPrice += serviceCharge;
jTextArea1.append(String.format("\nVehicle Number:                                                               %-25s\n", VehicleComboBox.getSelectedItem().toString()));
jTextArea1.append(String.format("Telephone Number:                                                     %-25s\n", txttelephone.getText()));
jTextArea1.append(String.format("Service Charge:                                                                      %-25s\n", txtservicecharge.getText()));
jTextArea1.append(String.format("%-40s\n", "------------------------------------------------------------------------------------------------------"));
jTextArea1.append(String.format("\nTotal Price:                                                                       %-25s\n", String.format("%.2f", totalPrice)));
    }
    }//GEN-LAST:event_jButton3ActionPerformed
private void populateVehicleComboBox() {
    try {
        // SQL query to get vehicle IDs
        String query = "SELECT vid FROM Vehicle"; // Adjust the query to match your table and column names
        // Execute the query
        try ( // Create a statement
                PreparedStatement pstmt = conn.prepareStatement(query); // Execute the query
                ResultSet rs = pstmt.executeQuery()) {
            
            // Clear the combo box
            VehicleComboBox.removeAllItems();
            
            // Add items to the combo box
            while (rs.next()) {
                String vehicleId = rs.getString("vid");
                VehicleComboBox.addItem(vehicleId);
            }
            
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading vehicle IDs: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
private void populateItemComboBox() {
    try {
        // SQL query to get vehicle IDs
        String query = "SELECT Iid FROM Itemstock"; // Adjust the query to match your table and column names
        // Execute the query
        try ( // Create a statement
                PreparedStatement pstmt = conn.prepareStatement(query); // Execute the query
                ResultSet rs = pstmt.executeQuery()) {
            
            // Clear the combo box
            itemcombobox.removeAllItems();
            
            // Add items to the combo box
            while (rs.next()) {
                String itemid = rs.getString("Iid");
                itemcombobox.addItem(itemid);
            }
            
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading Item IDs: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private void VehicleComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VehicleComboBoxActionPerformed
        
    }//GEN-LAST:event_VehicleComboBoxActionPerformed

    private void itemcomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemcomboboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemcomboboxActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       new Cashier_CashierPart().setVisible(true);
       this.dispose();
       generateBillAndItemIds();
       
    }//GEN-LAST:event_jButton5ActionPerformed

    private void addtableitemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addtableitemMouseClicked
    int selectedRow = addtableitem.getSelectedRow();
    if (selectedRow >= 0) {
        TableModel model = addtableitem.getModel();

        // Assuming column indices are 0-based:
        // Item ID (column 0), Item Name (column 1), Price per Item (column 2), Quantity (column 3)
        itemcombobox.setSelectedItem(model.getValueAt(selectedRow, 0).toString());
        txtitemname.setText(model.getValueAt(selectedRow, 1).toString());
        txtpriceperitem.setText(model.getValueAt(selectedRow, 3).toString());
        txtquantity.setText(model.getValueAt(selectedRow, 2).toString());
    }
    }//GEN-LAST:event_addtableitemMouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
       
    
    String itemId = itemcombobox.getSelectedItem().toString();
      String itemName = txtitemname.getText(); // Get the item name from the text field
    String quantity = txtquantity.getText();
    String pricePerItem = txtpriceperitem.getText();
  
    
    // Calculate total price for the current item
    double totalPrice = Double.parseDouble(pricePerItem) ;
    
    // Add the item details to the table
    javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) addtableitem.getModel();
    model.addRow(new Object[]{ itemId, itemName, quantity, totalPrice}); // Add itemName to the row data
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
    
            txtitemname.setText(""); // Clear the item name text field
    txtquantity.setText(""); // Clear the quantity text field
    txtpriceperitem.setText(""); // Clear the price per item text field
    int selectedRow = addtableitem.getSelectedRow();

    if (selectedRow >= 0) {
        DefaultTableModel model = (DefaultTableModel) addtableitem.getModel();
        model.removeRow(selectedRow);
    } else {
        JOptionPane.showMessageDialog(this, "Please select an item to remove.", "No Selection", JOptionPane.WARNING_MESSAGE);
    }

    // Clear the combo box and text fields
    itemcombobox.setSelectedIndex(-1); // Deselect the item in the combo box
    txtitemname.setText(""); // Clear the item name text field
    txtquantity.setText(""); // Clear the quantity text field
    txtpriceperitem.setText(""); // Clear the price per item text field
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cashier_CashierPart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cashier_CashierPart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cashier_CashierPart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cashier_CashierPart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Cashier_CashierPart().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> VehicleComboBox;
    private javax.swing.JTable addtableitem;
    private javax.swing.JComboBox<String> itemcombobox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private com.toedter.calendar.JDateChooser jDateChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField txtbillId;
    private javax.swing.JTextField txtitemname;
    private javax.swing.JTextField txtpriceperitem;
    private javax.swing.JTextField txtquantity;
    private javax.swing.JTextField txtservicecharge;
    private javax.swing.JTextField txttelephone;
    private javax.swing.JTextField txttotal;
    // End of variables declaration//GEN-END:variables
}
