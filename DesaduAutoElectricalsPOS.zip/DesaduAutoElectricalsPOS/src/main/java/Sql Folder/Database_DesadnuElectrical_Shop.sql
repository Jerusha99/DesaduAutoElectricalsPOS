-- Creating the database and switching to it
CREATE DATABASE EAD1;
USE EAD1;

-- EmployeeDetails Table
CREATE TABLE EmployeeDetails (
    eid INT AUTO_INCREMENT PRIMARY KEY,  
    ename VARCHAR(50),
    emobilenumber VARCHAR(15),
    eparentmobilenumber VARCHAR(15),
    eaddress VARCHAR(50),
    edob DATE,
    eStatus VARCHAR(50)
);

-- Itemstock Table
CREATE TABLE Itemstock (
    Iid INT AUTO_INCREMENT PRIMARY KEY,  
    Iname VARCHAR(50),
    Iprice DECIMAL(10, 2),
    Iqty INT,
    Idate DATE,
    Iexpirydate DATE,
    eStatus VARCHAR(50),
    managed_by INT,
    CONSTRAINT fk_managed_by FOREIGN KEY (managed_by) REFERENCES EmployeeDetails(eid)
);

-- Vehicle Table (linked to EmployeeDetails for vehicle assignments)
CREATE TABLE Vehicle (
    vid VARCHAR(50) PRIMARY KEY,
    vehicleType VARCHAR(50),
    CustomerName VARCHAR(50),
    Telephone VARCHAR(15),
    Idate DATE,
    eStatus VARCHAR(50),
    assigned_to INT,  
    CONSTRAINT fk_vehicle_employee FOREIGN KEY (assigned_to) REFERENCES EmployeeDetails(eid)
);

-- CustomerDetails Table (linked to EmployeeDetails for customer handling)
CREATE TABLE CustomerDetails (
    cid INT AUTO_INCREMENT PRIMARY KEY,  
    cname VARCHAR(50),
    cmobilenumber VARCHAR(15),
    cVehicleNumber VARCHAR(50),
    caddress VARCHAR(50),
    cStatus VARCHAR(50),
    handled_by INT,  
    CONSTRAINT fk_customer_employee FOREIGN KEY (handled_by) REFERENCES EmployeeDetails(eid)
);

-- CashierDetails Table (linked to EmployeeDetails for cashier activities)
CREATE TABLE CashierDetails (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,  
    item_id INT NOT NULL,  
    quantity INT NOT NULL,
    price_per_item DECIMAL(10, 2) NOT NULL,
    date DATE NOT NULL,
    telephone_number VARCHAR(15) NOT NULL,
    vehicle_number VARCHAR(50) NOT NULL,
    service_charge DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    item_name VARCHAR(50),
    cashier_id INT,  
    CONSTRAINT fk_item FOREIGN KEY (item_id) REFERENCES Itemstock(Iid),
    CONSTRAINT fk_cashier_employee FOREIGN KEY (cashier_id) REFERENCES EmployeeDetails(eid)
);

-- ActivityLog Table (linked to EmployeeDetails for logging activities)
CREATE TABLE ActivityLog (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,  
    username VARCHAR(100),
    action_type VARCHAR(50), 
    description TEXT, 
    action_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_employee FOREIGN KEY (user_id) REFERENCES EmployeeDetails(eid)
);

-- AdminRegistration Table
CREATE TABLE AdminRegistration (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,  
    userid VARCHAR(50) NOT NULL UNIQUE,       
    password VARCHAR(255) NOT NULL  
);

-- Example Insert Statements
INSERT INTO AdminRegistration (userid, password)
VALUES 
    ('Emp1', SHA2('admin', 256)),  
    ('Emp2', SHA2('admin', 256));  

-- Triggers for EmployeeDetails Table
DELIMITER $$

CREATE TRIGGER after_employee_insert
AFTER INSERT ON EmployeeDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.eid, NEW.ename, 'INSERT', CONCAT('Inserted new employee: ', NEW.ename));
END $$

CREATE TRIGGER after_employee_update
AFTER UPDATE ON EmployeeDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.eid, NEW.ename, 'UPDATE', CONCAT('Updated employee details for: ', NEW.ename));
END $$

CREATE TRIGGER after_employee_delete
AFTER DELETE ON EmployeeDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (OLD.eid, OLD.ename, 'DELETE', CONCAT('Deleted employee: ', OLD.ename));
END $$

-- Triggers for Itemstock Table
CREATE TRIGGER after_item_insert
AFTER INSERT ON Itemstock
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.managed_by, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.managed_by), 'INSERT', CONCAT('Inserted new item: ', NEW.Iname));
END $$

CREATE TRIGGER after_item_update
AFTER UPDATE ON Itemstock
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.managed_by, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.managed_by), 'UPDATE', CONCAT('Updated item details for: ', NEW.Iname));
END $$

CREATE TRIGGER after_item_delete
AFTER DELETE ON Itemstock
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (OLD.managed_by, (SELECT ename FROM EmployeeDetails WHERE eid = OLD.managed_by), 'DELETE', CONCAT('Deleted item: ', OLD.Iname));
END $$

-- Triggers for Vehicle Table
CREATE TRIGGER after_vehicle_insert
AFTER INSERT ON Vehicle
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.assigned_to, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.assigned_to), 'INSERT', CONCAT('Assigned new vehicle: ', NEW.vehicleType));
END $$

CREATE TRIGGER after_vehicle_update
AFTER UPDATE ON Vehicle
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.assigned_to, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.assigned_to), 'UPDATE', CONCAT('Updated vehicle details for: ', NEW.vehicleType));
END $$

CREATE TRIGGER after_vehicle_delete
AFTER DELETE ON Vehicle
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (OLD.assigned_to, (SELECT ename FROM EmployeeDetails WHERE eid = OLD.assigned_to), 'DELETE', CONCAT('Deleted vehicle: ', OLD.vehicleType));
END $$

-- Triggers for CustomerDetails Table
CREATE TRIGGER after_customer_insert
AFTER INSERT ON CustomerDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.handled_by, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.handled_by), 'INSERT', CONCAT('Inserted new customer: ', NEW.cname));
END $$

CREATE TRIGGER after_customer_update
AFTER UPDATE ON CustomerDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.handled_by, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.handled_by), 'UPDATE', CONCAT('Updated customer details for: ', NEW.cname));
END $$

CREATE TRIGGER after_customer_delete
AFTER DELETE ON CustomerDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (OLD.handled_by, (SELECT ename FROM EmployeeDetails WHERE eid = OLD.handled_by), 'DELETE', CONCAT('Deleted customer: ', OLD.cname));
END $$

-- Triggers for CashierDetails Table
CREATE TRIGGER after_cashier_insert
AFTER INSERT ON CashierDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.cashier_id, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.cashier_id), 'INSERT', CONCAT('Inserted cashier transaction for bill ID: ', NEW.bill_id));
END $$

CREATE TRIGGER after_cashier_update
AFTER UPDATE ON CashierDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (NEW.cashier_id, (SELECT ename FROM EmployeeDetails WHERE eid = NEW.cashier_id), 'UPDATE', CONCAT('Updated cashier transaction for bill ID: ', NEW.bill_id));
END $$

CREATE TRIGGER after_cashier_delete
AFTER DELETE ON CashierDetails
FOR EACH ROW
BEGIN
    INSERT INTO ActivityLog (user_id, username, action_type, description)
    VALUES (OLD.cashier_id, (SELECT ename FROM EmployeeDetails WHERE eid = OLD.cashier_id), 'DELETE', CONCAT('Deleted cashier transaction for bill ID: ', OLD.bill_id));
END $$

DELIMITER ;

-- Select statement to view data
SELECT * FROM AdminRegistration;

-- Sample SELECT statements to view data
SELECT * FROM CashierDetails;
SELECT * FROM Vehicle;
SELECT * FROM Itemstock;
SELECT * FROM EmployeeDetails;

-- To drop the database
DROP DATABASE EAD1;

-- Select statement for ActivityLog
SELECT * FROM ActivityLog;


