package Admin_Login_Form;
// Add these imports at the top of your file
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Admin_Or_CashierLogin extends javax.swing.JFrame {
// Button hover effects
    private boolean jButton1Hover = false;
    private boolean jButton2Hover = false;
    // Add these variables
  
    public Admin_Or_CashierLogin() {
 try {
        UIManager.setLookAndFeel(new FlatLightLaf());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error setting look and feel: " + e.getMessage());
    }

    initComponents();
    setupBackground();
    setupTitleAnimation();
    styleButtons();
    ScaleImage();
        
    }
    private void setupTitleAnimation() {
    jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 24));
    jLabel1.setForeground(new Color(255, 255, 255));

    Timer titleTimer = new Timer(50, e -> {
        float hue = (System.currentTimeMillis() % 2000) / 2000.0f;
        jLabel1.setForeground(Color.getHSBColor(hue, 0.5f, 0.9f));
        jLabel1.repaint();
    });
    titleTimer.start();
}private void setupBackground() {
    JPanel backgroundPanel = new JPanel() {
        private float gradientPhase = 0.0f;

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            float[] fractions = {0.0f, 1.0f};
            Color[] colors = {
                new Color(0, 102, 204),
                new Color(0, 153, 255, 200)
            };
            Point2D center = new Point2D.Float(getWidth() / 2.0f, getHeight() / 2.0f);
            RadialGradientPaint paint = new RadialGradientPaint(
                center, getWidth() / 1.5f, fractions, colors
            );
            g2d.setPaint(paint);
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.dispose();

            gradientPhase += 0.005f;
            if (gradientPhase > 1.0f) gradientPhase = 0.0f;
        }
    };
    backgroundPanel.setOpaque(true);
    setContentPane(backgroundPanel);
    backgroundPanel.setLayout(new BorderLayout());
    backgroundPanel.add(jPanel1, BorderLayout.NORTH);
    backgroundPanel.add(createMainPanel(), BorderLayout.CENTER);

    Timer backgroundTimer = new Timer(50, e -> backgroundPanel.repaint());
    backgroundTimer.start();
}
    private JPanel createMainPanel() {
    JPanel mainPanel = new JPanel(new GridLayout(1, 2, 10, 10));
    mainPanel.setOpaque(false);

    // Left panel for image
    JPanel leftPanel = new JPanel(new BorderLayout());
    leftPanel.setOpaque(false);
    leftPanel.add(jLabel3, BorderLayout.CENTER);
    mainPanel.add(leftPanel);

    // Right panel for form
    JPanel rightPanel = new JPanel(new GridBagLayout());
    rightPanel.setOpaque(false);
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.CENTER;
    jLabel4.setFont(new Font("Segoe UI", Font.BOLD, 16));
    jLabel4.setForeground(Color.WHITE);
    rightPanel.add(jLabel4, gbc);

    gbc.gridy = 1;
    jLabel2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    jLabel2.setForeground(Color.WHITE);
    rightPanel.add(jLabel2, gbc);

    gbc.gridy = 2;
    cmbrole.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    cmbrole.setPreferredSize(new Dimension(200, 30));
    rightPanel.add(cmbrole, gbc);

    gbc.gridy = 3;
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
    buttonPanel.setOpaque(false);
    buttonPanel.add(jButton1);
    buttonPanel.add(jButton2);
    rightPanel.add(buttonPanel, gbc);

    mainPanel.add(rightPanel);
    return mainPanel;
}
private void styleButtons() {
    // Next button
    jButton1 = new JButton("Next") {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Background
            Color baseColor = jButton1Hover ? new Color(0, 153, 255) : new Color(0, 102, 204);
            g2d.setPaint(baseColor);
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);

            // Hover glow
            if (jButton1Hover) {
                g2d.setColor(new Color(255, 255, 255, 50));
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 10, 10);
            }

            // Text
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
            FontMetrics fm = g2d.getFontMetrics();
            int textX = (getWidth() - fm.stringWidth(getText())) / 2;
            int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2d.drawString(getText(), textX, textY);
            g2d.dispose();
        }
    };
    jButton1.setForeground(Color.WHITE);
    jButton1.setContentAreaFilled(false);
    jButton1.setBorderPainted(false);
    jButton1.setFocusPainted(false);
    jButton1.setPreferredSize(new Dimension(100, 40));
    jButton1.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            jButton1Hover = true;
            jButton1.repaint();
        }

        @Override
        public void mouseExited(MouseEvent e) {
            jButton1Hover = false;
            jButton1.repaint();
        }
    });
    jButton1.addActionListener(evt -> jButton1ActionPerformed(evt));

    // Back button
    jButton2 = new JButton("Back") {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Background
            Color baseColor = jButton2Hover ? new Color(200, 200, 200) : new Color(150, 150, 150);
            g2d.setPaint(baseColor);
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);

            // Hover glow
            if (jButton2Hover) {
                g2d.setColor(new Color(255, 255, 255, 50));
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 10, 10);
            }

            // Text
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
            FontMetrics fm = g2d.getFontMetrics();
            int textX = (getWidth() - fm.stringWidth(getText())) / 2;
            int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2d.drawString(getText(), textX, textY);
            g2d.dispose();
        }
    };
    jButton2.setForeground(Color.WHITE);
    jButton2.setContentAreaFilled(false);
    jButton2.setBorderPainted(false);
    jButton2.setFocusPainted(false);
    jButton2.setPreferredSize(new Dimension(100, 40));
    jButton2.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            jButton2Hover = true;
            jButton2.repaint();
        }

        @Override
        public void mouseExited(MouseEvent e) {
            jButton2Hover = false;
            jButton2.repaint();
        }
    });
    jButton2.addActionListener(evt -> jButton2ActionPerformed(evt));
}
private void ScaleImage() {
    // Create ImageIcon with the image path
    ImageIcon icon = new ImageIcon("C:\\Users\\Jerusha\\Documents\\EAD_FINAL_PROJECT\\EAD_FINAL_PROJECT\\src\\main\\java\\resource\\2.jpg");
    
    // Set the icon to the JLabel
    jLabel3.setIcon(icon);
}
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cmbrole = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(153, 255, 255));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Login Page");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(346, 346, 346)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(23, 23, 23))
        );

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel2.setText("Login Method");

        cmbrole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrator", "Cashier" }));

        jButton1.setText("Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Welcome To Desandu Auto Electricals");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(67, 67, 67)
                                .addComponent(cmbrole, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton1)
                                .addGap(37, 37, 37)
                                .addComponent(jButton2)
                                .addGap(71, 71, 71)))
                        .addGap(17, 17, 17))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbrole, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(98, 98, 98)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2))
                        .addGap(164, 164, 164))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        if ("Administrator".equals(cmbrole.getSelectedItem()) ) {
            new Admin_Login().setVisible(true); 
            this.dispose();
        } else if ("Cashier".equals(cmbrole.getSelectedItem())) {
            new Cashier_Login().setVisible(true); 
            this.dispose();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      
         new Start_Menu().setVisible(true); 
            this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_Or_CashierLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_Or_CashierLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_Or_CashierLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_Or_CashierLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Admin_Or_CashierLogin().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbrole;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
