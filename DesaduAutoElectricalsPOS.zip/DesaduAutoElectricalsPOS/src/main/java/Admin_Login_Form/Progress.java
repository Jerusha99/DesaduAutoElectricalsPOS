package Admin_Login_Form;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Progress extends JFrame {
    private JProgressBar progressBar;
    private JLabel titleLabel;
    private JPanel mainPanel;
    private Timer fadeTimer, progressTimer, pulseTimer;
    private float opacity = 0.0f;
    private float pulseScale = 1.0f;
    private boolean pulseIncreasing = true;

    public Progress() {
        initComponents();
        setupAnimations();
        setSize(new Dimension(868, 524));
        setLocationRelativeTo(null);
        setOpacity(0.0f);
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 50, 50));
    }

    private void initComponents() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        // Main panel with gradient background
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(0, 102, 204), // Blue
                    getWidth(), getHeight(), new Color(0, 255, 255) // Cyan
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout(0, 20));

        // Title label with shadow and custom font
        titleLabel = new JLabel("Desandu Auto Electricals", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                // Apply pulsating scale
                g2d.translate(getWidth() / 2.0, getHeight() / 2.0);
                g2d.scale(pulseScale, pulseScale);
                g2d.translate(-getWidth() / 2.0, -getHeight() / 2.0);

                // Shadow
                g2d.setColor(new Color(0, 0, 0, 50));
                g2d.setFont(getFont());
                g2d.drawString(getText(), 4, getHeight() - 4);

                // Text
                g2d.setColor(Color.WHITE);
                g2d.drawString(getText(), 0, getHeight());
                g2d.dispose();
            }
        };
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        


        // Progress bar with custom colors and rounded corners
        progressBar = new JProgressBar() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Background
                g2d.setColor(new Color(255, 255, 255, 100));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);

                // Foreground with animated gradient
                int progressWidth = (int) (getWidth() * ((double) getValue() / getMaximum()));
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(0, 255, 128), // Green
                    progressWidth, 0, new Color(0, 255, 255) // Cyan
                );
                g2d.setPaint(gradient);
                g2d.fillRoundRect(0, 0, progressWidth, getHeight(), 20, 20);
                g2d.dispose();
            }
        };
        progressBar.setMaximum(100);
        progressBar.setValue(0);
        progressBar.setStringPainted(true);
        progressBar.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        progressBar.setForeground(Color.CYAN);
        progressBar.setBorderPainted(false);
        progressBar.setPreferredSize(new Dimension(600, 30));
        JPanel progressPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        progressPanel.setOpaque(false);
        progressPanel.add(progressBar);
        mainPanel.add(progressPanel, BorderLayout.SOUTH);

        // Create a layered pane to properly handle overlapping components
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setOpaque(false);
        
        // Particle animation panel
        JPanel particlePanel = new ParticlePanel();
        particlePanel.setOpaque(false);
        particlePanel.setBounds(0, 0, 868, 424); // Match the full size
        layeredPane.add(particlePanel, JLayeredPane.DEFAULT_LAYER);
        
        // Create a container for the title to center it
        JPanel titleContainer = new JPanel(new GridBagLayout());
        titleContainer.setOpaque(false);
        titleContainer.setBounds(0, 0, 868, 424); // Match the full size
        
        // Add the title to its container with proper centering
        titleContainer.add(titleLabel);
        layeredPane.add(titleContainer, JLayeredPane.PALETTE_LAYER);
        
        mainPanel.add(layeredPane, BorderLayout.CENTER);

        setContentPane(mainPanel);
        pack();
    }

    private void setupAnimations() {
        // Fade-in animation
        fadeTimer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opacity += 0.02f;
                setOpacity(Math.min(opacity, 1.0f));
                if (opacity >= 1.0f) {
                    fadeTimer.stop();
                }
            }
        });

        // Progress animation
        progressTimer = new Timer(50, new ActionListener() {
            int value = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                value++;
                progressBar.setValue(value);
                progressBar.setString(value + "%");
                progressBar.repaint();
                if (value >= 100) {
                    progressTimer.stop();
                    startFadeOut();
                }
            }
        });

        // Pulsating title animation
        pulseTimer = new Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pulseIncreasing) {
                    pulseScale += 0.005f;
                    if (pulseScale >= 1.05f) pulseIncreasing = false;
                } else {
                    pulseScale -= 0.005f;
                    if (pulseScale <= 0.95f) pulseIncreasing = true;
                }
                titleLabel.repaint();
            }
        });
    }

    private void startFadeOut() {
        fadeTimer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opacity -= 0.02f;
                setOpacity(Math.max(opacity, 0.0f));
                if (opacity <= 0.0f) {
                    fadeTimer.stop();
                    dispose();
                   new Admin_Or_CashierLogin().setVisible(true);
                }
            }
        });
        fadeTimer.start();
    }

    // Particle animation panel
    private class ParticlePanel extends JPanel {
        private final int PARTICLE_COUNT = 50;
        private final Particle[] particles;

        public ParticlePanel() {
            setOpaque(false);
            particles = new Particle[PARTICLE_COUNT];
            for (int i = 0; i < PARTICLE_COUNT; i++) {
                particles[i] = new Particle();
            }
            Timer particleTimer = new Timer(16, e -> {
                for (Particle p : particles) {
                    p.update();
                }
                repaint();
            });
            particleTimer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            for (Particle p : particles) {
                p.draw(g2d);
            }
        }

        private class Particle {
            private float x, y;
            private float vx, vy;
            private float size;
            private Color color;

            public Particle() {
                reset();
            }

            private void reset() {
                x = (float) (Math.random() * getWidth());
                y = (float) (Math.random() * getHeight());
                vx = (float) (Math.random() * 2 - 1);
                vy = (float) (Math.random() * 2 - 1);
                size = (float) (Math.random() * 5 + 2);
                color = new Color(255, 255, 255, (int) (Math.random() * 100 + 50));
            }

            public void update() {
                x += vx;
                y += vy;
                if (x < 0 || x > getWidth()) vx = -vx;
                if (y < 0 || y > getHeight()) vy = -vy;
                if (Math.random() < 0.01) reset();
            }

            public void draw(Graphics2D g2d) {
                g2d.setColor(color);
                g2d.fillOval((int) x, (int) y, (int) size, (int) size);
            }
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        Progress splash = new Progress();
        EventQueue.invokeLater(() -> {
            splash.setVisible(true);
            splash.fadeTimer.start();
            splash.progressTimer.start();
            splash.pulseTimer.start();
        });
    }
}